<?php

$email = $_POST['email'];

$password = $_POST['password'];

$adress1 = $_POST['adress1'];

$adress2 = $_POST['adress2'];

$City = $_POST['City'];

$State = $_POST['State'];

$Zip = $_POST['Zip'];

//database connection
$conn =new mysqli('localhost','root','','registration');
if( $conn ->connect_error){
    die('Connection Failed :' .$conn->connect_error);}
else{
    $stmt = $conn->prepare("insert into data(email,password.adress1,adress2,City,State,Zip)
    values(?,?,?,?,?,?,?)");
    $stmt->bind_param("ssssssi", $email ,$password,$adress1,$adress2,$City,$State,$Zip);
    $stmt->execute();
    echo"Thank You! Your record is registered.";
    $stmt->close();
    $conn->close();
}


?>